# AB-650 compact exam course v3

Open AB650-Complete-Course.html for learning and scored practice. Read AB650-Training-Guide.pdf for the short core. Study one module, explain its decisions, complete its two checks and record practical evidence. Then take Mixed A and B on separate days.

Targets are local design choices, not calibrated pass predictions. Read current Microsoft instructions for live labs and product prerequisites.
