# Ten practical case cards

All records below are fictional. These are reasoning simulations, not live execution. Answer before opening the model response. Use the evidence worksheet to separate observed outcomes, assumptions and work not tested. For live work, follow the current official AB-650 labs in an appropriate training tenant.

## 01. Assignment and recovery

Data: Product P has 12 available seats. Group G has 10 direct users and nested group H with users U11/U12. G shows no errors. User U03 shows the intended product and service plan. Backup protects Site A. The requested file was deleted from Site B yesterday; no Site B recovery point is shown.

Task: identify two unsupported success claims and the evidence needed to close them.

Model response: 12 group-related users does not mean 12 licences from G; inspect U11/U12 assignment sources and use supported direct membership if approved. No errors is not proof those nested users were processed. Site A protection does not prove Site B recovery. Inspect Site B scope and available historical recovery points; a new policy now does not establish yesterday's recovery. U03's result is evidence only for U03.

## 02. Resource boundary

Data: RAC allowed group is Finance. Ana is in Finance and has Read. Ben is in Finance but lacks site permission. Chen has a direct Read link but is not in Finance. The site also uses RCD.

Task: predict direct access for all three. Would changing RCD resolve Ben's issue?

Model response: Ana satisfies the RAC boundary and underlying permission; Ben and Chen do not. Ben lacks permission, while Chen fails the group boundary. RCD changes discovery, not Ben's permission. Record actual allowed and denied tests after propagation; predictions are not execution evidence.

## 03. Bulk identity result

Data: update file contains (U01, Sales), (U02, Finance), (U02, HR), (U03, Support). Result log: U01 success; first U02 success; duplicate U02 rejected; U03 throttled, outcome not yet checked.

Task: reconcile completion and plan a safe retry.

Model response: two successful rows are confirmed. The duplicate has a conflicting department intent that must be resolved with the request owner. U03 needs state inspection and the documented retry process; do not assume failed transport means no change. Validate unique IDs before execution. Replaying the entire file without reconciliation is poor evidence and may repeat completed work.

## 04. Sign-in policy timeline

Data: 09:10 UTC, user T1, modern client, SharePoint. P1 is On, requires MFA, Success. Authentication Details: satisfied by claim in token. P2 is Report-only, device requirement, Report-only: failure. Final sign-in: Success.

Task: explain MFA, device enforcement and the missing new prompt.

Model response: MFA was satisfied by the existing claim. No fresh challenge is established. P2 evaluated but did not enforce its device requirement. The successful request does not establish device compliance. If P2 were enforced and applicable, its unsatisfied requirement would change the decision; verify with a fresh authorised test.

## 05. Threat precedence and response

Data: recipient R1 matches Strict preset, Standard preset and custom anti-phishing priority 0. No preset exception applies. Timeline: 10:00 message delivered; 10:04 alert created; 10:06 removal requested; 10:08 action Pending. No user-click event is supplied.

Task: choose the effective policy and state a defensible case status.

Model response: applicable Strict governs the anti-phishing feature; custom priority does not outrank it. Delivery is confirmed. Removal is not confirmed. Click and compromise are not established. Investigate user impact and verify remediation completion before closure. A request timestamp is not a successful action result.

## 06. Protection requirements

Data: contracts must be classified Confidential and retained seven years. Requirement A stops account numbers sent to external recipients. Requirement B stops supported sensitive text typed directly into Copilot prompts. Copilot policy is Simulation and logs a match.

Task: choose the control families and explain the observed response.

Model response: configure sensitivity handling/publication and retention separately. A uses the Exchange location, appropriate account-number detection and supported external-mail action. B uses a separate custom Copilot-only policy with supported prompt detection/action; check preview availability. Simulation records rather than blocks. Do not assume uploaded file contents are directly typed prompt text.

## 07. Readiness and user setting

Data: U1 has the relevant licence and web Copilot works; desktop experience is absent. U2 uses desktop Copilot but retrieves an overly broadly shared finance file. A disclaimer appears. Cowork legacy registry entry is blocked; U2 remains in a current spending policy selecting Cowork.

Task: name three separate investigations.

Model response: check U1's signed-in account, supported desktop client and experience prerequisites. Review U2's underlying finance access and sharing; the disclaimer does not repair it. Review applicable Cowork spending-policy access and current product prerequisites, then test fresh requests after changes. Do not diagnose all symptoms as a single licensing issue.

## 08. Connector permissions

Data: synced source item C17 allowed U1 and U2 at yesterday's full crawl. Source ACL removes U2 today. An incremental content crawl completes. U2 still sees C17. A different federated source uses user OAuth and live source authorisation.

Task: choose the synced repair and describe the federated approval boundary.

Model response: confirm source ACL and mapping, run the required full crawl for ACL changes and retest the removed user after processing. Validate a permitted user against the same item too. For the federated source, test runtime source authorisation and approved transfer. No persistent content index does not mean no data transfer.

## 09. Agent scope and approval

Data: blueprint B1 has child agent A1 and paired user PU1. The registry listing is approved. Package AP1 grants Procurement Read for 30 days. Tool X requests HR Write. Sponsor S1 has left. A blueprint block stops A1's fresh token request; PU1's sign-in succeeds.

Task: list the unresolved governance items and interpret the token evidence.

Model response: reassign accountability, review/reject the excess tool grant, confirm AP1 resources and expiry/review policy, and test approved Procurement access plus HR denial. Registry approval does not justify HR Write. A1's fresh token result supports the child-policy block; PU1 is a separate subject needing its own supported user scope and event evidence. Do not conclude the child block failed because PU1 succeeded.

## 10. Adoption and duplicate cost

Data: eligible users 100, licensed users 80, active users 60 for the same month and workload. Microsoft 365 and Azure each show a £120 PAYG line with the same resource, meter and date. An Azure budget email is sent at £100; the resource keeps running. An agent with no current owner has no visible activity in an unverified dashboard scope.

Task: calculate both adoption figures, propose booked cost and state the monitoring limits.

Model response: eligible adoption is 60%; licensed-user adoption is 75%. State denominators. Reconcile charge identity; if both lines are the same charge, book £120 once. Azure budget email is notification, not automatic stopping. Inspect reporting scope and delay before saying the agent was inactive; ownership remains a governance gap regardless of visible activity.

## Evidence standard

For each case, record the requirement, object, applicable control, expected result, supplied observation, untested assumption and next verification. An acceptable response identifies the deciding mechanism and does not turn a prediction, saved setting or pending action into a confirmed result. Critical identity, permission and enforcement mistakes require correction even when quiz scores are high.
