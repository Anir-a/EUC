# If required, install approved modules using your organization’s normal process.
# Install-Module Microsoft.Graph.Authentication -Scope CurrentUser
# Install-Module Microsoft.Graph.Users -Scope CurrentUser
$LabTenantId = "REPLACE-WITH-AUTHORIZED-LAB-TENANT-ID"
Connect-MgGraph -TenantId $LabTenantId -Scopes "User.Read.All" -ContextScope Process
Get-MgContext | Select-Object TenantId, Account, Scopes
# STOP if the tenant or account is not the approved lab identity.
Get-MgUser -All -Property Id,DisplayName,UserPrincipalName,UserType,AccountEnabled |
    Select-Object Id,DisplayName,UserPrincipalName,UserType,AccountEnabled |
    Export-Csv -Path "./AB650-Lab-Users.csv" -NoTypeInformation -Encoding UTF8
Disconnect-MgGraph