# Inventory only. No tenant writes. Requires Microsoft.Graph.Users module.
# Review and consent only to the approved delegated read permission.
Connect-MgGraph -Scopes 'User.ReadBasic.All'
Get-MgContext | Select-Object TenantId, Account, AuthType, Scopes
Get-MgUser -Top 5 -Property Id,DisplayName,UserPrincipalName |
    Select-Object Id,DisplayName,UserPrincipalName
Disconnect-MgGraph
